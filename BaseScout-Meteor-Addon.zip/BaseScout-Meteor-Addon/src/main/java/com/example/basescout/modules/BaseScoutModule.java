package com.example.basescout.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

import java.util.HashSet;
import java.util.Set;

public class BaseScoutModule extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval")
        .description("Ticks entre escaneos.")
        .defaultValue(20)
        .min(1)
        .sliderMax(100)
        .build());

    private final Setting<Integer> radius = sgGeneral.add(new IntSetting.Builder()
        .name("radius")
        .description("Radio en bloques alrededor del jugador.")
        .defaultValue(32)
        .min(8)
        .sliderMax(64)
        .build());

    private final Setting<Integer> minSignals = sgGeneral.add(new IntSetting.Builder()
        .name("minimum-signals")
        .description("Cantidad mínima de bloques de interés para registrar una ubicación.")
        .defaultValue(4)
        .min(1)
        .sliderMax(30)
        .build());

    private final Setting<Boolean> notify = sgGeneral.add(new BoolSetting.Builder()
        .name("notify")
        .description("Muestra una notificación al encontrar una zona de interés.")
        .defaultValue(true)
        .build());

    private final Set<Long> discoveries = new HashSet<>();
    private int ticks;

    public BaseScoutModule() {
        super(BaseScout.CATEGORY, "base-scout", "Detecta señales de construcciones visibles en los chunks cargados.");
    }

    @Override
    public void onActivate() {
        ticks = 0;
        discoveries.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        if (++ticks < scanInterval.get()) return;
        ticks = 0;

        BlockPos center = mc.player.getBlockPos();
        int r = radius.get();
        int signals = 0;
        BlockPos first = null;

        for (int x = center.getX() - r; x <= center.getX() + r; x++) {
            for (int y = Math.max(mc.world.getBottomY(), center.getY() - 12);
                 y <= Math.min(mc.world.getTopYInclusive(), center.getY() + 12); y++) {
                for (int z = center.getZ() - r; z <= center.getZ() + r; z++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (isSignal(mc.world.getBlockState(p).getBlock())) {
                        signals++;
                        if (first == null) first = p.toImmutable();
                        if (signals >= minSignals.get()) break;
                    }
                }
                if (signals >= minSignals.get()) break;
            }
            if (signals >= minSignals.get()) break;
        }

        if (signals >= minSignals.get() && first != null) {
            long key = (((long) first.getX()) << 32) ^ (first.getZ() & 0xffffffffL);
            if (discoveries.add(key) && notify.get()) {
                info("Zona de interés detectada cerca de %d, %d, %d.", first.getX(), first.getY(), first.getZ());
            }
        }
    }

    private boolean isSignal(Block b) {
        return b == Blocks.CHEST
            || b == Blocks.BARREL
            || b == Blocks.FURNACE
            || b == Blocks.BLAST_FURNACE
            || b == Blocks.SMOKER
            || b == Blocks.CRAFTING_TABLE
            || b == Blocks.BREWING_STAND
            || b == Blocks.ENCHANTING_TABLE
            || b == Blocks.BEACON
            || b == Blocks.ENDER_CHEST;
    }
}
