package com.example.basescout;

import com.example.basescout.modules.BaseScoutModule;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class BaseScout extends MeteorAddon {
    @Override
    public void onInitialize() {
        Modules.get().add(new BaseScoutModule());
    }

    @Override
    public void onRegisterCategories() {
    }

    @Override
    public String getPackage() {
        return "com.example.basescout";
    }

    @Override
    public String getWebsite() {
        return "https://github.com/example/basescout";
    }
}
