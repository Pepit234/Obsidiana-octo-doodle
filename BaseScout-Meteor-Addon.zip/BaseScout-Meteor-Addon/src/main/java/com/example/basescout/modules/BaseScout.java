package com.example.basescout.modules;

import meteordevelopment.meteorclient.systems.modules.Module;

public final class BaseScout {
    public static final Module.Categories CATEGORY = Module.Categories.World;
    private BaseScout() {}
}
